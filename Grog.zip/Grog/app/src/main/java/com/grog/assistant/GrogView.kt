package com.grog.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Круглый объёмный смайлик Грог. Рисуется в координатах 380x380. */
class GrogView(context: Context) : View(context) {

    enum class Mode { IDLE, THINKING, SPEAKING }

    @Volatile var mode = Mode.IDLE
    @Volatile var running = false
    private var hearUntil = 0L

    val isHearing: Boolean get() = SystemClock.uptimeMillis() < hearUntil

    /** Вызывается, когда микрофон слышит звук. */
    fun hear() {
        hearUntil = SystemClock.uptimeMillis() + 500
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val smile = Path()

    private val EDGE = Color.parseColor("#E39A0B")
    private val MID = Color.parseColor("#FFB920")
    private val LIGHT = Color.parseColor("#FFCF45")
    private val LIGHTER = Color.parseColor("#FFDD73")
    private val FOOT = Color.parseColor("#B26A00")
    private val DARK = Color.parseColor("#4A2E00")
    private val CHEEK = Color.parseColor("#FF8A5C")

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, color: Int, alpha: Int = 255) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = alpha
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawOval(rect, paint)
    }

    private fun hand(c: Canvas, x: Float, y: Float) {
        oval(c, x, y, 23f, 23f, EDGE)
        oval(c, x - 2f, y - 3f, 20f, 20f, MID)
        oval(c, x - 5f, y - 7f, 14f, 14f, LIGHT)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val hearing = isHearing
        val m = mode

        c.save()
        c.scale(width / 380f, height / 380f)

        // тень и ножки
        oval(c, 190f, 340f, 95f, 12f, Color.BLACK, 36)
        val step = if (running) sin(t * 14f) * 10f else 0f
        oval(c, 150f + step, 313f, 24f, 12f, FOOT)
        oval(c, 232f - step, 313f, 24f, 12f, FOOT)

        // подпрыгивание при беге
        val bob = if (running) -abs(sin(t * 9f)) * 12f else sin(t * 2f) * -3f
        c.translate(0f, bob)

        // ручки (машет, когда слышит голос или говорит)
        val swing = if (running) sin(t * 14f) * 12f else 0f
        hand(c, 73f, 215f + swing)
        if (hearing || m == Mode.SPEAKING) {
            hand(c, 318f + sin(t * 10f) * 8f, 105f)
        } else {
            hand(c, 307f, 212f - swing)
        }

        // тело: слои для объёма
        oval(c, 190f, 185f, 120f, 120f, EDGE)
        oval(c, 182f, 177f, 113f, 113f, MID)
        oval(c, 173f, 168f, 100f, 100f, LIGHT)
        oval(c, 165f, 160f, 82f, 82f, LIGHTER, 140)
        c.save()
        c.rotate(-35f, 128f, 105f)
        oval(c, 128f, 105f, 34f, 17f, Color.WHITE, 178)
        c.restore()

        // глаза
        val blink = (now % 3500L) < 140L
        val rx = if (hearing) 18f else 15f
        val ry = if (blink) 2.5f else if (hearing) 28f else 23f
        val ey = if (m == Mode.THINKING) 158f else 168f
        oval(c, 156f, ey, rx, ry, DARK)
        oval(c, 222f, ey, rx, ry, DARK)
        if (!blink) {
            oval(c, 160f, ey - 10f, 5f, 5f, Color.WHITE)
            oval(c, 226f, ey - 10f, 5f, 5f, Color.WHITE)
        }

        // щёчки
        oval(c, 124f, 214f, 16f, 16f, CHEEK, 128)
        oval(c, 256f, 214f, 16f, 16f, CHEEK, 128)

        // рот
        when (m) {
            Mode.SPEAKING -> {
                val open = (sin(t * 18f) + 1f) / 2f
                oval(c, 190f, 242f, 30f, 6f + 20f * open, DARK)
            }
            Mode.THINKING -> oval(c, 190f, 245f, 9f, 9f, DARK)
            else -> {
                smile.reset()
                smile.moveTo(142f, 224f)
                smile.quadTo(190f, 282f, 238f, 224f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 8f
                paint.strokeCap = Paint.Cap.ROUND
                paint.color = DARK
                paint.alpha = 255
                c.drawPath(smile, paint)
            }
        }

        c.restore()
        postInvalidateOnAnimation()
    }
}
